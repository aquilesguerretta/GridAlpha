# Todo
- #2: Add additional market intelligence features (load forecasting, demand curves)
